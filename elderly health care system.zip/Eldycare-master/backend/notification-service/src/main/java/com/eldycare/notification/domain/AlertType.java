package com.eldycare.notification.domain;

public enum AlertType {
    CARDIAC,FALL
}
