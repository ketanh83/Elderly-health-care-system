package com.ensias.eldycare.userservice.model;

public enum UserType {
    RELATIVE, ELDERLY
}
