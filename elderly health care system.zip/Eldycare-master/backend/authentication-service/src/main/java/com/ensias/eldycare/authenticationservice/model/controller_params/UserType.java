package com.ensias.eldycare.authenticationservice.model.controller_params;

public enum UserType {
    RELATIVE,ELDERLY
}
