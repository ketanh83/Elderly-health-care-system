package com.eldycare.reminder.constants;

public class ServiceConstants {

    public static final String SOMETHING_WENT_WRONG = "Something went wrong.";

    public static final String INVALID_DATA = "Invalid Data.";
    public static final String REMINDER_SENT_SUCCESSFULLY = "Reminder sent successfully.";

}