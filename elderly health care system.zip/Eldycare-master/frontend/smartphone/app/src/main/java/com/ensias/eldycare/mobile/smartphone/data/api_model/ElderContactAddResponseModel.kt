package com.ensias.eldycare.mobile.smartphone.data.api_model

data class ElderContactAddResponseModel(
    val message: String
)
