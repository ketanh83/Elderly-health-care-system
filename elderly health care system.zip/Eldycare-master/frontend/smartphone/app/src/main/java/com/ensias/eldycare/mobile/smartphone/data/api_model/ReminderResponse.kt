package com.ensias.eldycare.mobile.smartphone.data.api_model

data class ReminderResponse(
    val message: String
)
