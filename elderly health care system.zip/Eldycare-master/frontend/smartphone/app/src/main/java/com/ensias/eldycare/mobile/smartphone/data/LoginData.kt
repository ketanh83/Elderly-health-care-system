package com.ensias.eldycare.mobile.smartphone.data

data class LoginData(
    val email: String,
    val password: String,
)
