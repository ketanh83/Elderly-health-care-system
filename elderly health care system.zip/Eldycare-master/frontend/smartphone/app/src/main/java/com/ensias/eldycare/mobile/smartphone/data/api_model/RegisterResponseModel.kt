package com.ensias.eldycare.mobile.smartphone.data.api_model

data class RegisterResponseModel(
    val message: String,
    val user: User
)