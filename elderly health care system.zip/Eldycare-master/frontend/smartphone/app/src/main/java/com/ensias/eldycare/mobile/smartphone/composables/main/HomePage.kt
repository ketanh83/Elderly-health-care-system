package com.ensias.eldycare.mobile.smartphone.composables.main

/**
 * Should wrap AlertsPage and RemindersPage
 * The content should be a list of reminders and alerts as a variable that we pass for the sub pages to render
 */
class HomePage {
}