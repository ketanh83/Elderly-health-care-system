package com.ensias.eldycare.mobile.smartphone.data.model

data class AuthLoginModel(
    val email: String,
    val password: String
)