package com.ensias.eldycare.mobile.smartphone.data

object Constants {
    val CHANNEL_ID = "ALERT_NOTIFICATIONS"
}
