package com.ensias.eldycare.mobile.smartphone

enum class UserType {
    RELATIVE, ELDERLY
}