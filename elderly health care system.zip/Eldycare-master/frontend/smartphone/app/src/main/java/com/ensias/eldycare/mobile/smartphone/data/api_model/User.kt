package com.ensias.eldycare.mobile.smartphone.data.api_model

data class User(
    val email: String,
    val id: Int,
    val userType: String,
    val username: String
)