package com.ensias.eldycare.mobile.smartphone.data

enum class AlertType {
    CARDIAC,FALL
}