package com.ensias.eldycare.mobile.smartphone.data.api_model

data class NotificationResponse(
    val message: String
)
